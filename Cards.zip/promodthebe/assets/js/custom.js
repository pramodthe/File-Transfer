$(document).ready(function () {
	/*********** Nav menu ***************/
	$('.bar-icon,.close-icon').click(function () {
		$('.header-right').toggleClass('offcanvas-menu');
		return false;
	});
	$('a[href*=#]').bind('click', function(e) {
		e.preventDefault();

		var target = $(this).attr("href");
		$('html, body').stop().animate({
				scrollTop: $(target).offset().top
		}, 600, function() {
				location.hash = target;
		});
			return false;
	});


});
$(document).ready(function() {
	$('.slider').customcarousel({
		numVisible:3,
		autoplay:true,
	}); 
	$('#prev').click(function() {
		$('.slider').customcarousel('prev');
	});
	
	$('#next').click(function() {
		$('.slider').customcarousel('next');
	});
});
